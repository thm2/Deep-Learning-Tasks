"""Perceptron model."""

import numpy as np


class Perceptron:
    def __init__(self, n_class: int, lr: float, epochs: int):
        """Initialize a new classifier.

        Parameters:
            n_class: the number of classes
            lr: the learning rate
            epochs: the number of epochs to train for
        """
        self.w = 1  # TODO: change this.
        self.lr = lr
        self.epochs = epochs
        self.n_class = n_class

    def train(self, X_train: np.ndarray, y_train: np.ndarray):
        """Train the classifier.

        Use the perceptron update rule as introduced in Lecture 3.

        Parameters:
            X_train: a number array of shape (N, D) containing training data;
                N examples with D dimensions
            y_train: a numpy array of shape (N,) containing training labels
        """
        # TODO: implement me
        D = X_train.shape[1];
        

        
        if self.n_class == 2:
            y_train = np.where(y_train == 1, 1, -1)

            self.w =  np.random.uniform(-1, 1,(1,D))
            for epoch in range(self.epochs):
                for x,y in zip(X_train,y_train):
                    if np.sign(self.w @ x.T)!=y:
                        self.w += (self.lr*np.exp(-epoch))*y*x
        else:

            self.w =  np.random.uniform(-1, 1,(self.n_class,D))
            for epoch in range(self.epochs):
                for x,y,i in zip(X_train,y_train,range(X_train.shape[0])):
                    wx = self.w @ x.T
                    change_c = wx>wx[y]
                    summ = sum(change_c)
                    self.w[y] += summ*(self.lr*np.exp(-epoch))*x.T
                    self.w[change_c] -= (self.lr*np.exp(-epoch))*x.T

        pass
        

    def predict(self, X_test: np.ndarray) -> np.ndarray:
        """Use the trained weights to predict labels for test data points.

        Parameters:
            X_test: a numpy array of shape (N, D) containing testing data;
                N examples with D dimensions

        Returns:
            predicted labels for the data in X_test; a 1-dimensional array of
                length N, where each element is an integer giving the predicted
                class.
        """
        # TODO: implement me
        predictions = np.zeros(X_test.shape[0])

        
        if self.n_class == 2:    
            for x,i in zip(X_test, range(X_test.shape[0])):
                predictions[i] = 1 if np.sign(self.w @ x.T) >=0 else 0;
        else:
            for i in range(X_test.shape[0]):
                predictions[i] = np.argmax(self.w @ X_test[i,:].T) 
     
        predictions = np.array(predictions,dtype=int)
        
        return predictions