"""Support Vector Machine (SVM) model."""

import numpy as np


class SVM:
    def __init__(self, n_class: int, lr: float, epochs: int, reg_const: float):
        """Initialize a new classifier.

        Parameters:
            n_class: the number of classes
            lr: the learning rate
            epochs: the number of epochs to train for
            reg_const: the regularization constant
        """
        self.w = 1  # TODO: change this.
        self.alpha = lr
        self.epochs = epochs
        self.reg_const = reg_const
        self.n_class = n_class

    def calc_gradient(self, X_train: np.ndarray, y_train: np.ndarray) -> np.ndarray:
        """Calculate gradient of the svm hinge loss.

        Inputs have dimension D, there are C classes, and we operate on
        mini-batches of N examples.

        Parameters:
            X_train: a numpy array of shape (N, D) containing a mini-batch
                of data
            y_train: a numpy array of shape (N,) containing training labels;
                y[i] = c means that X[i] has label c, where 0 <= c < C

        Returns:
            the gradient with respect to weights w; an array of the same shape
                as w
        """
        # TODO: implement me
        
        
        return

    def train(self, X_train: np.ndarray, y_train: np.ndarray):
        """Train the classifier.

        Hint: operate on mini-batches of data for SGD.

        Parameters:
            X_train: a numpy array of shape (N, D) containing training data;
                N examples with D dimensions
            y_train: a numpy array of shape (N,) containing training labels
        """
        # TODO: implement me
        D = X_train.shape[1];
        
        # X_train = np.c_[X_train,np.ones((X_train.shape[0],1))]

        if self.n_class == 2:
            y_train = np.where(y_train == 1, 1, -1)
            self.w = np.random.uniform(-1, 1,(1,D))
            for epoch in range(self.epochs):
                for x,y in zip(X_train,y_train):
                    if y*self.w @ x.T < 1:
                        self.w = self.w + (self.alpha*np.exp(-epoch)) * (y*x - self.reg_const/X_train.shape[0] * self.w)
                    else:
                        self.w *= 1 -  (self.alpha*np.exp(-epoch)) * self.reg_const/X_train.shape[0]
        else:
            self.w = np.random.uniform(-1, 1,(self.n_class,D))
            
            Data = np.c_[X_train, y_train]
            for epoch in range(self.epochs):  
                np.random.shuffle(Data)
                XX_train = Data[:,:-1]
                yy_train = Data[:,-1]
                N = XX_train.shape[0]
                for x,y,i in zip(XX_train,yy_train.astype('int'),range(N)):
                    # print('test')
                    self.w*= 1 -  (self.alpha/(1+epoch)) * self.reg_const/N
                    wx = self.w @ x.T
                    change_c = wx+1>wx[y]
                    summ = sum(change_c)
                    self.w[y] += summ*(self.alpha*np.exp(-epoch))*x.T
                    self.w[change_c] -= (self.alpha*np.exp(-epoch))*x.T
           

        
        pass

    def predict(self, X_test: np.ndarray) -> np.ndarray:
        """Use the trained weights to predict labels for test data points.

        Parameters:
            X_test: a numpy array of shape (N, D) containing testing data;
                N examples with D dimensions

        Returns:
            predicted labels for the data in X_test; a 1-dimensional array of
                length N, where each element is an integer giving the predicted
                class.
        """
        # TODO: implement me
        
        predictions = np.zeros(X_test.shape[0])


        if self.n_class == 2:    
            for x,i in zip(X_test, range(X_test.shape[0])):
                predictions[i] = 1 if np.sign(self.w @ x.T) >=0 else 0;
        else:
            for i in range(X_test.shape[0]):
                predictions[i] = np.argmax(self.w @ X_test[i,:].T) 
     
        predictions = np.array(predictions,dtype=int)
        
        return predictions
