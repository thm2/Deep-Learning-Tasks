from models.SVM import *
from models.Perceptron import *
from models.Softmax import *
from models.Logistic import *
