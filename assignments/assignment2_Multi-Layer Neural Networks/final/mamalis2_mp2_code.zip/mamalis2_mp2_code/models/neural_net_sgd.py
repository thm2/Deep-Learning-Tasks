"""Neural network model with SGD."""

from typing import Sequence

import numpy as np


class NeuralNetwork:
    """A multi-layer fully-connected neural network. The net has an input
    dimension of N, a hidden layer dimension of H, and performs classification
    over C classes. We train the network with a softmax loss function and L2
    regularization on the weight matrices.

    The network uses a nonlinearity after each fully connected layer except for
    the last. The outputs of the last fully-connected layer are the scores for
    each class."""

    def __init__(
        self,
        input_size: int,
        hidden_sizes: Sequence[int],
        output_size: int,
        num_layers: int,
    ):
        """Initialize the model. Weights are initialized to small random values
        and biases are initialized to zero. Weights and biases are stored in
        the variable self.params, which is a dictionary with the following
        keys:

        W1: 1st layer weights; has shape (D, H_1)
        b1: 1st layer biases; has shape (H_1,)
        ...
        Wk: kth layer weights; has shape (H_{k-1}, C)
        bk: kth layer biases; has shape (C,)

        Parameters:
            input_size: The dimension D of the input data
            hidden_size: List [H1,..., Hk] with the number of neurons Hi in the
                hidden layer i
            output_size: The number of classes C
            num_layers: Number of fully connected layers in the neural network
        """
        self.input_size = input_size
        self.hidden_sizes = hidden_sizes
        self.output_size = output_size
        self.num_layers = num_layers
        self.learning_rate_decay = 0
        self.loss = 0
        self.num_epochs = 0
                

        assert len(hidden_sizes) == (num_layers - 1)
        sizes = [input_size] + hidden_sizes + [output_size]

        self.params = {}
        for i in range(1, num_layers + 1):
            self.params["W" + str(i)] = np.random.randn(
                sizes[i], sizes[i-1]
            ) / np.sqrt(sizes[i])
            self.params["b" + str(i)] = np.zeros((sizes[i],1))

    def one_hot_encoding(self,y, k):
        """Numeric class values to one hot vectors
        
        Parameters:
            y:  An array of labels of length N
            k:  Number of classes
        
        Returns: A 2d array of shape (N x K), where K is the number of classes
        """

        Y_one_h = np.eye(k)[y]
        Y_one_h = Y_one_h.T

        return Y_one_h
    
    def relu(self, X: np.ndarray) -> np.ndarray:
        """Rectified Linear Unit (ReLU).

        Parameters:
            X: the input data

        Returns:
            the output
        """
        rel = np.maximum(X, 0)
        
        return rel

    def softmax(self, Z_last: np.ndarray) -> np.ndarray:
         """The softmax function.

         Parameters:
             X: the input data

         Returns:
             the output
         """   

         numerator = np.exp(Z_last - np.max(Z_last, axis=0, keepdims=True))
         denominator = np.sum(numerator, axis=0, keepdims=True)
         Y_hat = numerator / denominator

         return  Y_hat
    

    def forward(self, X: np.ndarray, Y_true: np.array, reg: int = 0.0):
        """Compute the scores for each class for all of the data samples.

        Hint: this function is also used for prediction.

        Parameters:
            X: Input data of shape (N, D). Each X[i] is a training or
                testing sample

        Returns:
            Matrix of shape (N, C) where scores[i, c] is the score for class
                c on input X[i] outputted from the last layer of your network
        """
        
        self.outputs = {}
        
        X=X.T;
        Y_true=Y_true.T

        Z=X;
        A=Z;
        self.outputs["A_0"]=A;
        self.outputs["Z_0"]=Z;

        for layer in range(1,self.num_layers):
            Z = self.params["W" + str(layer)] @ A + self.params["b" + str(layer)]
            A = self.relu(Z);
            self.outputs["Z_"+str(layer)]=Z
            self.outputs["A_"+str(layer)]=A
          
          
        Z_last = self.params["W" + str(self.num_layers)] @ A + self.params["b" + str(self.num_layers)]
        A_last = self.softmax(Z_last) 
            
        self.outputs["A_last"]=A_last
        self.outputs["Z_last"]=Z_last

        num_classes =  self.output_size
        self.y_one_ht = self.one_hot_encoding(Y_true,num_classes)
        y_pred = np.argmax(A_last, axis=0)
        z = Z_last - np.max(Z_last, axis=0, keepdims=True)
        
        self.loss += self.loss_fcn(self.y_one_ht, z, reg, self.params['W'+str(self.num_layers)])

        return y_pred


    def loss_fcn(self, y_one_ht, Z_last_stable, reg, W_last):
        loss=0.0
        num_observ=Z_last_stable.shape[1]
        for i in range(num_observ):
            loss += -y_one_ht[:, i].T @ Z_last_stable[:, i] + np.log(np.sum(np.exp(Z_last_stable[:, i])))
        loss += loss + reg/2 * np.linalg.norm(W_last, 'fro')**2
        return loss


    def backward(
        self, X: np.ndarray, Y_true: np.ndarray, lr: float, epoch: int, reg: float = 0.0
    ) -> float:
        """Perform back-propagation and update the parameters using the
        gradients.

        Parameters:
            X: Input data of shape (N, D). Each X[i] is a training sample
            y: Vector of training labels. y[i] is the label for X[i], and each
                y[i] is an integer in the range 0 <= y[i] < C
            lr: Learning rate
            reg: Regularization strength

        Returns:
            Total loss for this batch of training samples
        """
        self.gradients = {}
        
        X=X.T
        Y_true=Y_true.T
        
        dZ = self.outputs['A_last'] - self.y_one_ht
        self.gradients['dW'+str(self.num_layers)] = 1 / X.shape[0] * dZ @ self.outputs['A_'+str(self.num_layers-1)].T
        self.gradients['db'+str(self.num_layers)] = 1 / X.shape[0] * np.sum(dZ, axis = 1, keepdims=True)
        self.gradients['dZ'+str(self.num_layers)] =  dZ   
       
        for layer in range(self.num_layers-1, 0, -1):
            dZ = self.params['W'+str(layer+1)].T @ dZ * (self.outputs['Z_'+ str(layer)]>0)*1
            self.gradients['dW' + str(layer)] = 1 / X.shape[0] * dZ @ self.outputs['A_' + str(layer-1)].T + reg *self.params['W' + str(layer)]
            self.gradients['db' + str(layer)] = 1 / X.shape[0] * np.sum(dZ, axis = 1, keepdims=True)
            self.gradients['dZ'+str(layer)] =  dZ
            
        Learning_rate = lr * self.learning_rate_decay**epoch
        
        for layer in range(1, self.num_layers + 1):
            self.params['W'+str(layer)] -= Learning_rate * self.gradients['dW'+str(layer)] 
            self.params['b'+str(layer)] -= Learning_rate * self.gradients['db'+str(layer)]
           

        return self.loss